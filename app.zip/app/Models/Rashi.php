<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Rashi extends Model {
    protected $fillable = ['name', 'english_name', 'is_active', 'sort_order'];
    protected $casts    = ['is_active' => 'boolean'];
}
