<header class="header">
  <div class="container">
    <nav class="nav">

      {{-- LOGO --}}
      <a href="{{ route('home') }}" class="nav-logo">
        <img src="{{ asset('assets/images/logo.png') }}" alt="BouddhMatrimony" onerror="this.style.display='none'">
        <div>
          <span>Express </span>
          <span style="color:var(--accent)">Matrimony</span>
        </div>
      </a>

      {{-- DESKTOP NAV --}}
      <ul class="nav-links">
        <li><a href="{{ route('home') }}" class="{{ request()->routeIs('home') ? 'active' : '' }}">Home</a></li>
        <li><a href="{{ route('about') }}" class="{{ request()->routeIs('about') ? 'active' : '' }}">About Us</a></li>
        <li><a href="{{ route('packages') }}" class="{{ request()->routeIs('packages') ? 'active' : '' }}">Packages</a></li>
        <li><a href="{{ route('contact') }}" class="{{ request()->routeIs('contact') ? 'active' : '' }}">Contact Us</a></li>
      </ul>

      {{-- RIGHT SIDE --}}
      <div class="nav-actions">

        @guest
          {{-- GUEST --}}
          <a href="{{ route('user.login') }}" class="btn btn-outline btn-sm">Login</a>
          <a href="{{ route('user.register') }}" class="btn btn-primary btn-sm">Register Free</a>
        @endguest

        @auth
          {{-- AUTH USER --}}
          <div style="display:flex;align-items:center;gap:12px;">

            {{-- DASHBOARD --}}
            <a href="{{ route('user.dashboard') }}" class="btn btn-outline btn-sm">
              Dashboard
            </a>

            {{-- USER MENU --}}
            <div style="position:relative;">

              <button onclick="toggleUserMenu()" class="btn btn-primary btn-sm" style="display:flex;align-items:center;gap:8px;">
                
                {{-- PROFILE IMAGE --}}
                <img 
                  src="{{ Auth::user()->primaryPhoto->url ?? asset('assets/images/default-user.png') }}"
                  style="width:28px;height:28px;border-radius:50%;object-fit:cover;">

                <span>{{ Auth::user()->name ?? 'User' }}</span>
              </button>

              {{-- DROPDOWN --}}
              <div id="userMenu" style="
                position:absolute;
                right:0;
                top:110%;
                background:#fff;
                border:1px solid var(--border);
                border-radius:12px;
                box-shadow:var(--shadow-md);
                padding:10px 0;
                min-width:200px;
                display:none;
                z-index:999;
              ">

                <a href="{{ route('user.profile.me') }}" class="dropdown-item">👤 My Profile</a>
                <a href="{{ route('user.profile.edit') }}" class="dropdown-item">✏️ Edit Profile</a>
                <a href="{{ route('user.subscription.show') }}" class="dropdown-item">💎 My Plan</a>
                <a href="{{ route('user.settings.index') }}" class="dropdown-item">⚙️ Settings</a>

                <hr style="margin:8px 0;">

                <form method="POST" action="{{ route('user.logout') }}">
                  @csrf
                  <button type="submit" class="dropdown-item" style="width:100%;text-align:left;background:none;border:none;">
                    🚪 Logout
                  </button>
                </form>

              </div>
            </div>

          </div>
        @endauth

      </div>

      {{-- MOBILE BUTTON --}}
      <button class="hamburger" id="hamburger" aria-label="Menu">
        <span></span><span></span><span></span>
      </button>

    </nav>
  </div>

  {{-- MOBILE MENU --}}
  <div class="mobile-menu" id="mobileMenu">
    
    <ul>
      <li><a href="{{ route('home') }}">Home</a></li>
      <li><a href="{{ route('about') }}">About Us</a></li>
      <li><a href="{{ route('packages') }}">Packages</a></li>
      <li><a href="{{ route('contact') }}">Contact Us</a></li>
    </ul>

    <div class="mobile-actions">

      @guest
        <a href="{{ route('user.login') }}" class="btn btn-outline btn-sm" style="flex:1;justify-content:center">
          Login
        </a>
        <a href="{{ route('user.register') }}" class="btn btn-primary btn-sm" style="flex:1;justify-content:center">
          Register
        </a>
      @endguest

      @auth
        <a href="{{ route('user.dashboard') }}" class="btn btn-primary btn-sm" style="flex:1;justify-content:center">
          Dashboard
        </a>

        <form method="POST" action="{{ route('user.logout') }}" style="flex:1;">
          @csrf
          <button type="submit" class="btn btn-outline btn-sm" style="width:100%;">
            Logout
          </button>
        </form>
      @endauth

    </div>

  </div>
</header>


{{-- USER MENU SCRIPT --}}
<script>
function toggleUserMenu() {
  const menu = document.getElementById('userMenu');
  if (menu) {
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
  }
}

// close dropdown when clicking outside
document.addEventListener('click', function(e) {
  const menu = document.getElementById('userMenu');
  const btn = e.target.closest('button');

  if (!e.target.closest('#userMenu') && !btn) {
    if (menu) menu.style.display = 'none';
  }
});
</script>


{{-- OPTIONAL STYLE --}}
<style>
.dropdown-item {
  display:block;
  padding:10px 16px;
  font-size:0.9rem;
  color:var(--text);
  text-decoration:none;
  transition:var(--transition);
}
.dropdown-item:hover {
  background:var(--bg-light);
  color:var(--primary);
}
</style>