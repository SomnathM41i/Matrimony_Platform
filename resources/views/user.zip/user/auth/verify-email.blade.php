@extends('user.layouts.app')

@section('title', 'Verify Your Email')

@section('content')

<style>
    .main-content { display:flex; align-items:center; justify-content:center; min-height:calc(100vh - 58px); }
    .verify-card { background:var(--card-bg); border-radius:18px; border:1px solid var(--border); box-shadow:0 4px 24px rgba(180,100,60,.07); padding:50px 44px; max-width:480px; width:100%; text-align:center; }
    .verify-icon { width:68px; height:68px; border-radius:50%; background:linear-gradient(135deg,rgba(200,113,90,.15),rgba(201,168,108,.2)); display:flex; align-items:center; justify-content:center; font-size:1.8rem; margin:0 auto 24px; color:var(--rose); }
    .verify-card h3 { font-family:'Cormorant Garamond',serif; font-size:1.9rem; font-weight:600; color:var(--text-primary); margin-bottom:12px; }
    .verify-card p  { color:var(--text-muted); font-size:.85rem; line-height:1.7; margin-bottom:28px; }
    .verify-email-chip { display:inline-block; background:var(--bg-secondary); border:1px solid var(--border); border-radius:8px; padding:8px 16px; font-size:.83rem; color:var(--text-primary); font-weight:500; margin-bottom:28px; }
    .btn-full { width:100%; justify-content:center; }
    .resend-link { margin-top:16px; font-size:.78rem; color:var(--text-muted); }
    .resend-link form { display:inline; }
    .resend-link button { background:none; border:none; color:var(--rose); cursor:pointer; font-size:.78rem; font-weight:500; text-decoration:underline; }
    .logout-link { display:block; margin-top:18px; font-size:.75rem; color:var(--text-muted); text-decoration:none; }
    .logout-link:hover { color:var(--danger); }
</style>

<div class="verify-card">
    <div class="verify-icon"><i class="fas fa-envelope-circle-check"></i></div>

    <h3>Check your inbox</h3>

    <p>
        We've sent a verification link to:
    </p>
    <div class="verify-email-chip">{{ auth()->user()->email }}</div>
    <p>
        Click the link in that email to verify your account and unlock all features.
        If you don't see it, check your spam folder.
    </p>

    @if(session('success'))
        <div class="alert alert-success" style="text-align:left;margin-bottom:20px;">
            <i class="fas fa-check-circle"></i> {{ session('success') }}
        </div>
    @endif

    <div class="resend-link">
        Didn't receive the email?
        <form method="POST" action="{{ route('user.verification.send') }}">
            @csrf
            <button type="submit">Resend verification email</button>
        </form>
    </div>

    <form method="POST" action="{{ route('user.logout') }}" style="margin-top:18px;">
        @csrf
        <button type="submit" style="background:none;border:none;cursor:pointer;font-size:.75rem;color:var(--text-muted);">
            <i class="fas fa-right-from-bracket"></i> Logout and use a different account
        </button>
    </form>
</div>

@endsection