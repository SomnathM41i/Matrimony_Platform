<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('otp_tokens', function (Blueprint $table) {
            $table->id();
            $table->string('identifier');
            $table->enum('type', ['email_verify','phone_verify','password_reset','login']);
            $table->string('token', 10);
            $table->boolean('is_used')->default(false);
            $table->unsignedTinyInteger('attempts')->default(0);
            $table->timestamp('expires_at');
            $table->timestamps();
            $table->index(['identifier', 'type', 'is_used']);
        });
    }
    public function down(): void { Schema::dropIfExists('otp_tokens'); }
};
