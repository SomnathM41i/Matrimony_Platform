<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create("cities", function (Blueprint $table) {
            $table->id();
            $table->foreignId("state_id")->constrained()->cascadeOnDelete();
            $table->string("name");
            $table->boolean("is_active")->default(true);
            $table->unsignedSmallInteger("sort_order")->default(0);
            $table->timestamps();
            $table->index("state_id");
        });
    }
    public function down(): void { Schema::dropIfExists("cities"); }
};
